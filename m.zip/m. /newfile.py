from pyrogram import Client
import asyncio,random,threading,time

id,haah = 15551290 , "52541a59f55c6f54678a4ec33e708e0f"

app1 = Client("c/cc",api_id=id,api_hash=haah)
app2 = Client("c/cc2",api_id=id,api_hash=haah)
app3 = Client("c/cc3",api_id=id,api_hash=haah)
app4 = Client("c/cc4",api_id=id,api_hash=haah)
app5 = Client("c/cc5",api_id=id,api_hash=haah)
app6 = Client("c/cc6",api_id=id,api_hash=haah)
app7 = Client("c/cc7",api_id=id,api_hash=haah)
app8 = Client("c/cc8",api_id=id,api_hash=haah)
app9 = Client("c/cc9",api_id=id,api_hash=haah)
app10 = Client("c/cc10",api_id=id,api_hash=haah)
app11 = Client("c/cc11",api_id=id,api_hash=haah)
app1.start()
print(1)
app2.start()
print(2)
app3.start()
print(3)
app4.start()
print(4)
app5.start()
print(5)
app6.start()
print(6)
app7.start()
app8.start()
app9.start()
print(7)
app10.start()
print(8)
app11.start()
print(11)

yym = [app1,app2,app3,app4,app5,app9,app10,app11]
tet = ['راتب','بخشيش']
chatid = "kxkdnxkxk"
Join = False

if Join :
    for xx in yym :
        try:
            xx.join_chat(chatid)
        except Exception as h:
         print(h)
         pass 
        
while True:
    for xx in yym :
       try:
        xx.send_message(chatid,tet[0])
        xx.send_message(chatid,tet[1])        
       except Exception as h:
        print(h)
        pass 
    time.sleep(605)
  

#while True: 
# try:
#  if 1 == 1 :
#   app1.send_message(chatid,'راتب')
#   app1.send_message(chatid,'بخشيش')
#    app2.send_message(chatid,'راتب')
#   app2.send_message(chatid,'بخشيش')
#   app3.send_message(chatid,'راتب')
#   app3.send_message(chatid,'بخشيش')
#   app4.send_message(chatid,'راتب')
#   app4.send_message(chatid,'بخشيش')
#   app5.send_message(chatid,'راتب')
#   app5.send_message(chatid,'بخشيش')
#   app9.send_message(chatid,'راتب')
#   app9.send_message(chatid,'بخشيش')
#   app10.send_message(chatid,'راتب')
#   app10.send_message(chatid,'بخشيش')
#   app11.send_message(chatid,'راتب')
#   app11.send_message(chatid,'بخشيش')
# except Exception as h:
#            print(h)
#            pass                      

 
               
            
  
#for x in range(90) : x = threading.Thread(target=hi()).start()